"""Creates the Jal Drishti frontend and patches the backend to serve it.

Usage (from the repo root that contains backend/ and data/):
    python make_frontend.py            # uses the current folder
    python make_frontend.py path/to/repo
"""
import shutil
import sys
from pathlib import Path

FILES = {}

FILES["frontend/index.html"] = r'''
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Jal Drishti — ghats that need attention before Durga visarjan</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header class="topbar">
    <div class="brand">
      <h1>Jal Drishti <span lang="hi">जल दृष्टि</span></h1>
      <p>Which immersion ghats need attention before Durga visarjan. Built from MPPCB test reports 2023–2025 and
        compared with CPCB Class B (organised outdoor bathing) limits.</p>
    </div>
    <div class="countdown" id="countdown" aria-live="polite"></div>
  </header>

  <div id="banner" class="banner" role="alert" hidden></div>

  <section class="filters" aria-label="Filters">
    <label>Festival
      <select id="f-festival">
        <option value="Durga" selected>Durga</option>
        <option value="Ganesh">Ganesh</option>
        <option value="">Both festivals</option>
      </select>
    </label>
    <fieldset>
      <legend>Years</legend>
      <div id="f-years" class="years"></div>
    </fieldset>
    <label>Phase
      <select id="f-phase">
        <option value="" selected>All phases</option>
        <option value="during,after">During + 1 week after immersion</option>
        <option value="pre">Before immersion</option>
        <option value="during">During immersion</option>
        <option value="after">1 week after immersion</option>
      </select>
    </label>
    <span id="loading" class="loading" hidden>Loading…</span>
  </section>

  <main>
    <section class="panel" aria-labelledby="summary-h">
      <h2 id="summary-h">At a glance</h2>
      <div id="summary-cards" class="cards"></div>
      <ul id="headlines" class="headlines"></ul>
    </section>

    <div class="layout">
      <section class="panel" aria-labelledby="rank-h">
        <h2 id="rank-h">Ghats ranked by readings outside CPCB Class B</h2>
        <p class="muted" id="rank-scope"></p>
        <p class="muted small">Ranked by how often and how far dissolved oxygen, BOD and pH fall outside the limits.
          Missing readings are never counted as clean.</p>
        <div id="rankings"></div>
        <details id="method" class="method"></details>
      </section>

      <aside class="panel brief" aria-labelledby="brief-h">
        <h2 id="brief-h">Officer brief <span lang="hi">अधिकारी सारांश</span></h2>
        <div class="brief-controls">
          <div class="tabs" role="tablist" aria-label="Brief language">
            <button class="tab" role="tab" data-lang="en" aria-selected="true">English</button>
            <button class="tab" role="tab" data-lang="hi" aria-selected="false" lang="hi">हिंदी</button>
          </div>
          <label>Ghats listed
            <select id="brief-top">
              <option value="3" selected>3</option>
              <option value="5">5</option>
              <option value="7">7</option>
            </select>
          </label>
        </div>
        <h3 id="brief-title" class="brief-title"></h3>
        <div id="brief-body" class="brief-body"></div>
        <div class="brief-actions">
          <button id="copy-brief" class="btn">Copy</button>
          <button id="copy-both" class="btn-secondary">Copy EN + HI</button>
          <button id="download-brief" class="btn-secondary">Download .txt</button>
        </div>
        <p class="muted small">The Hindi text is generated from templates. Please have it checked before forwarding.</p>
      </aside>
    </div>

    <section class="panel" aria-labelledby="cov-h">
      <h2 id="cov-h">Data coverage</h2>
      <p class="muted small">Readings reported out of readings expected, for all 13 parameters, in each test round.
        "No table" means the report has no table for that ghat in that round.</p>
      <div id="coverage"></div>
      <div class="legend">
        <span class="chip cov-complete">Complete</span>
        <span class="chip cov-partial">Some readings missing</span>
        <span class="chip cov-none_reported">Nothing reported</span>
        <span class="chip cov-no_table_in_report">No table in report</span>
      </div>
    </section>

    <section class="panel" aria-labelledby="cav-h">
      <h2 id="cav-h">What this data does not tell you</h2>
      <ul id="caveats" class="caveats"></ul>
    </section>
  </main>

  <dialog id="ghat-dialog" aria-labelledby="ghat-title">
    <div class="dialog-head">
      <h2 id="ghat-title">Ghat readings</h2>
      <button class="btn-close" id="ghat-close" aria-label="Close">×</button>
    </div>
    <div id="ghat-body"></div>
  </dialog>

  <footer>
    Data: MPPCB Ganesh and Durga visarjan reports 2023, 2024 and 2025; CPCB water-quality criteria.
    Source page numbers are PDF pages of that year's report. Compares readings with limits only;
    it does not assess health effects.
  </footer>

  <script src="app.js"></script>
</body>
</html>
'''

FILES["frontend/styles.css"] = r'''
:root {
  --ink: #1d2939; --muted: #667085; --line: #e4e7ec; --bg: #f5f7f8; --panel: #fff;
  --accent: #0e7490; --accent-soft: #e6f4f7;
  --fail: #b42318; --fail-bg: #fef3f2;
  --ok: #067647; --ok-bg: #ecfdf3;
  --miss: #475467; --miss-bg: #f2f4f7;
  --bdl: #5925dc; --bdl-bg: #f4f3ff;
  --warn: #93370d; --warn-bg: #fffaeb;
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans", "Noto Sans Devanagari",
    "Nirmala UI", Mangal, sans-serif;
  color: var(--ink); background: var(--bg); line-height: 1.5;
}
* { box-sizing: border-box; }
body { margin: 0; }
[lang="hi"] { font-family: "Noto Sans Devanagari", "Nirmala UI", Mangal, system-ui, sans-serif; }
h1, h2, h3 { line-height: 1.25; margin: 0 0 .5rem; }
h2 { font-size: 1.15rem; }
h3 { font-size: 1rem; }
.muted { color: var(--muted); }
.small { font-size: .85rem; }

.topbar { display: flex; gap: 1rem; justify-content: space-between; align-items: center;
  padding: 1rem 1.5rem; background: var(--accent); color: #fff; }
.topbar h1 { font-size: 1.5rem; }
.topbar h1 span { font-weight: 500; opacity: .9; margin-left: .4rem; }
.topbar p { margin: .25rem 0 0; max-width: 60ch; opacity: .95; }
.countdown { text-align: right; white-space: nowrap; }
.countdown strong { font-size: 2rem; display: block; line-height: 1; }
.countdown span { display: block; font-size: .85rem; opacity: .9; }

.banner { margin: 1rem 1.5rem 0; padding: .75rem 1rem; border-radius: 8px;
  background: var(--fail-bg); color: var(--fail); border: 1px solid #fecdca; }

.filters { display: flex; flex-wrap: wrap; gap: 1rem 1.5rem; align-items: flex-end;
  padding: 1rem 1.5rem; background: var(--panel); border-bottom: 1px solid var(--line);
  position: sticky; top: 0; z-index: 5; }
.filters label, .brief-controls label, .dialog-filters label { display: flex; flex-direction: column;
  font-size: .85rem; color: var(--muted); gap: .25rem; }
.filters fieldset { border: 0; padding: 0; margin: 0; }
.filters legend { font-size: .85rem; color: var(--muted); margin-bottom: .25rem; }
.years { display: flex; gap: .75rem; }
.chk { flex-direction: row !important; align-items: center; gap: .35rem !important; color: var(--ink) !important; }
select { font: inherit; padding: .4rem .5rem; border: 1px solid #d0d5dd; border-radius: 6px;
  background: #fff; color: var(--ink); }
.loading { color: var(--accent); font-weight: 600; }

main { padding: 1rem 1.5rem 2rem; display: grid; gap: 1rem; }
.panel { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 1rem 1.25rem; }
.layout { display: grid; grid-template-columns: minmax(0, 2fr) minmax(300px, 1fr); gap: 1rem; align-items: start; }
.brief { position: sticky; top: 5.5rem; }

.cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: .75rem; }
.card { border: 1px solid var(--line); border-radius: 8px; padding: .75rem; }
.card-label { font-size: .8rem; color: var(--muted); text-transform: uppercase; letter-spacing: .03em; }
.card-value { font-size: 1.6rem; font-weight: 700; }
.card-sub { font-size: .8rem; color: var(--muted); }
.headlines { margin: .75rem 0 0; padding-left: 1.2rem; }

.ghat-card { border: 1px solid var(--line); border-radius: 10px; padding: 1rem; margin-bottom: .9rem; }
.ghat-card.unranked { background: var(--miss-bg); }
.ghat-card header { display: grid; grid-template-columns: auto 1fr auto; gap: 1rem; align-items: start; }
.rank { width: 2.4rem; height: 2.4rem; border-radius: 50%; background: var(--accent); color: #fff;
  display: grid; place-items: center; font-weight: 700; font-size: 1.1rem; }
.unranked .rank { background: var(--miss); }
.ghat-name h3 { margin: 0; font-size: 1.05rem; }
.ghat-name p { margin: 0; }
.hi { color: var(--ink); }
.score { min-width: 150px; text-align: right; }
.score-num { font-size: 1.4rem; font-weight: 700; }
.score-num small { font-size: .8rem; color: var(--muted); font-weight: 400; }
.bar { height: 6px; background: var(--line); border-radius: 3px; overflow: hidden; margin: .25rem 0; }
.bar span { display: block; height: 100%; background: var(--fail); }

.chips { display: flex; flex-wrap: wrap; gap: .4rem; margin: .75rem 0 .25rem; }
.chip { display: inline-block; padding: .15rem .55rem; border-radius: 999px; font-size: .8rem;
  border: 1px solid transparent; white-space: nowrap; }
.chip-fail { background: var(--fail-bg); color: var(--fail); border-color: #fecdca; }
.chip-ok { background: var(--ok-bg); color: var(--ok); border-color: #abefc6; }
.chip-missing { background: var(--miss-bg); color: var(--miss); border: 1px dashed #98a2b3; }
.chip-bdl { background: var(--bdl-bg); color: var(--bdl); border-color: #d9d6fe; }
.chip-none { background: #fff; color: var(--muted); border-color: var(--line); }

.warn { background: var(--warn-bg); color: var(--warn); border-radius: 6px; padding: .5rem .75rem;
  font-size: .9rem; margin: .5rem 0; }
.reasons { margin: .5rem 0; padding-left: 1.2rem; }
.reasons li { margin-bottom: .25rem; }
.card-caveats { margin: .5rem 0; padding-left: 1.2rem; font-size: .85rem; color: var(--warn); }
.evidence summary, .method summary { cursor: pointer; color: var(--accent); font-weight: 600; margin: .5rem 0; }
.method p { margin: .4rem 0; font-size: .9rem; }

.table-wrap { overflow-x: auto; }
table { border-collapse: collapse; width: 100%; font-size: .88rem; }
th, td { text-align: left; padding: .4rem .5rem; border-bottom: 1px solid var(--line); vertical-align: top; }
thead th { background: #f9fafb; font-weight: 600; white-space: nowrap; }
.unit { color: var(--muted); font-size: .8rem; }

.btn, .btn-secondary { font: inherit; border-radius: 6px; padding: .45rem .9rem; cursor: pointer; }
.btn { background: var(--accent); color: #fff; border: 1px solid var(--accent); }
.btn-secondary { background: #fff; color: var(--accent); border: 1px solid #b2dde5; }
.btn:hover, .btn-secondary:hover { filter: brightness(.95); }
.link { background: none; border: 0; padding: 0; font: inherit; color: var(--accent); cursor: pointer;
  text-align: left; text-decoration: underline; }
a { color: var(--accent); }

.brief-controls { display: flex; justify-content: space-between; align-items: flex-end; gap: .75rem; margin-bottom: .75rem; }
.tabs { display: flex; border: 1px solid #d0d5dd; border-radius: 6px; overflow: hidden; }
.tab { font: inherit; border: 0; background: #fff; padding: .4rem .9rem; cursor: pointer; color: var(--ink); }
.tab[aria-selected="true"] { background: var(--accent); color: #fff; }
.brief-title { font-size: .95rem; }
.brief-body { font-size: .92rem; max-height: 60vh; overflow-y: auto; border: 1px solid var(--line);
  border-radius: 8px; padding: .5rem .75rem; background: #fcfcfd; }
.brief-body p { margin: .4rem 0; }
.brief-actions { display: flex; flex-wrap: wrap; gap: .5rem; margin-top: .75rem; }

.cov { text-align: center; white-space: nowrap; }
.cov-complete { background: #d1fadf; }
.cov-partial { background: #fef0c7; }
.cov-none_reported, .cov-no_table_in_report {
  background: repeating-linear-gradient(45deg, #f2f4f7, #f2f4f7 6px, #e4e7ec 6px, #e4e7ec 12px); color: var(--miss); }
.cov-na { color: var(--muted); }
.legend { display: flex; flex-wrap: wrap; gap: .5rem; margin-top: .75rem; }
.legend .chip { color: var(--ink); }
.caveats { padding-left: 1.2rem; margin: 0; }
.caveats li { margin-bottom: .3rem; }

dialog { width: min(1100px, 95vw); max-height: 90vh; border: 0; border-radius: 12px; padding: 0; }
dialog::backdrop { background: rgba(16, 24, 40, .5); }
.dialog-head { display: flex; justify-content: space-between; align-items: center; padding: 1rem 1.25rem;
  border-bottom: 1px solid var(--line); position: sticky; top: 0; background: #fff; }
#ghat-body { padding: 1rem 1.25rem; }
.btn-close { font-size: 1.6rem; line-height: 1; background: none; border: 0; cursor: pointer; color: var(--muted); }
.dialog-filters { display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-end; margin-bottom: .75rem; }

footer { padding: 1rem 1.5rem 2rem; color: var(--muted); font-size: .85rem; }

@media (max-width: 900px) {
  .layout { grid-template-columns: 1fr; }
  .brief { position: static; }
  .ghat-card header { grid-template-columns: auto 1fr; }
  .score { grid-column: 1 / -1; text-align: left; }
  .filters { position: static; }
}
@media print {
  .filters, .brief-actions, .btn-secondary, .tabs, footer, .topbar .countdown { display: none !important; }
  body { background: #fff; }
  .layout { grid-template-columns: 1fr; }
  .brief-body { max-height: none; }
}
'''

FILES["frontend/app.js"] = r'''
"use strict";

/* Jal Drishti dashboard. Talks only to the local Jal Drishti API (no government systems). */

const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const num = (v) => (v == null ? "—" : String(Number(Number(v).toFixed(3))));

// API location: ?api=http://host:port overrides; same origin when served by the backend;
// localhost:8000 when index.html is opened directly from disk.
const API_BASE = (() => {
  const fromQuery = new URLSearchParams(location.search).get("api");
  if (fromQuery) return fromQuery.replace(/\/+$/, "");
  if (window.JAL_API_BASE) return String(window.JAL_API_BASE).replace(/\/+$/, "");
  if (location.protocol === "file:") return "http://localhost:8000";
  return "";
})();

const VISARJAN_DATE = new Date("2026-10-20T00:00:00+05:30"); // Durga visarjan date from the participant guide
const SHORT = { "Dissolved oxygen": "DO", BOD: "BOD", pH: "pH", Conductivity: "Conductivity" };
const PHASE = { pre: "Before", during: "During", after: "1 week after" };

const state = { allYears: [], brief: null, lang: "en", top: 3, ghat: null, loadSeq: 0 };

/* ---------- API ---------- */

async function api(path, params = {}) {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== "" && v != null) qs.set(k, v);
  const query = qs.toString();
  const url = `${API_BASE}${path}${query ? `?${query}` : ""}`;
  let res;
  try {
    res = await fetch(url, { headers: { Accept: "application/json" } });
  } catch {
    throw new Error(`Cannot reach the Jal Drishti API at ${API_BASE || location.origin}. Is the backend running?`);
  }
  let body;
  try {
    body = await res.json();
  } catch {
    throw new Error(`Unexpected response (${res.status}) from ${path}.`);
  }
  if (!res.ok) {
    const err = body.error || (body.data && body.data.error) || {};
    throw new Error(err.message || `Request to ${path} failed (${res.status}).`);
  }
  return body;
}

/* ---------- helpers ---------- */

function showError(msg) { const b = $("#banner"); b.textContent = msg; b.hidden = false; }
function clearError() { $("#banner").hidden = true; }
function setLoading(on) {
  $("#loading").hidden = !on;
  document.body.setAttribute("aria-busy", on ? "true" : "false");
}

function currentParams() {
  const checked = $$("#f-years input:checked").map((i) => i.value);
  const params = { festival: $("#f-festival").value, phase: $("#f-phase").value };
  if (checked.length && checked.length < state.allYears.length) params.year = checked.join(",");
  return { params, noYears: checked.length === 0 };
}

function sourceLink(src) {
  if (!src || !src.page) return "—";
  const title = esc(src.report || "Source report");
  if (!src.url) return `<span title="${title}">p. ${src.page}</span>`;
  return `<a href="${esc(`${src.url}#page=${src.page}`)}" target="_blank" rel="noopener" title="${title}">p. ${src.page}</a>`;
}

function valueCell(r) {
  if (r.measurement_status === "measured") {
    return `${num(r.value)}${r.unit_assumed ? ` <span class="unit">${esc(r.unit_assumed)}*</span>` : ""}`;
  }
  if (r.measurement_status === "below_detection") {
    return `<span class="chip chip-bdl" title="Below detection limit: very low, not zero">${esc(r.value_as_printed.trim() || "BDL")}</span>`;
  }
  const printed = r.value_as_printed.trim();
  return `<span class="chip chip-missing" title="Not sampled. Not treated as clean">Missing${printed ? ` (“${esc(printed)}”)` : ""}</span>`;
}

function limitText(cmp) {
  const c = cmp && cmp.criterion;
  if (!c) return "—";
  const op = { min: "≥ ", max: "≤ ", range: "" }[c.limit_type] || "";
  return `${op}${esc(c.limit)}${c.unit ? ` ${esc(c.unit)}` : ""}`;
}

function statusChip(r) {
  const c = r.comparison || {};
  const cls = c.criterion ? c.criterion.cpcb_class : "B";
  switch (c.status) {
    case "meets": return `<span class="chip chip-ok">Meets Class ${esc(cls)}</span>`;
    case "does_not_meet": return `<span class="chip chip-fail">Outside Class ${esc(cls)}</span>`;
    case "missing": return `<span class="chip chip-missing">Not compared (missing)</span>`;
    case "not_compared": return `<span class="chip chip-bdl">Not compared (BDL)</span>`;
    default: return `<span class="chip chip-none">No limit set</span>`;
  }
}

function paramChip(p) {
  const label = SHORT[p.parameter] || p.parameter;
  const c = p.criterion;
  if (p.compared === 0) return `<span class="chip chip-missing">${esc(label)}: no readings (${p.missing} missing)</span>`;
  const unit = c.unit ? ` ${c.unit}` : "";
  const dir = c.limit_type === "min" ? `below ${num(c.lower)}${unit}`
    : c.limit_type === "max" ? `above ${num(c.upper)}${unit}`
    : `outside ${num(c.lower)}–${num(c.upper)}`;
  const missing = p.missing ? ` · ${p.missing} missing` : "";
  return `<span class="chip ${p.does_not_meet ? "chip-fail" : "chip-ok"}" title="${esc(c.description)}">` +
    `${esc(label)} ${esc(dir)}: ${p.does_not_meet} of ${p.compared}${esc(missing)}</span>`;
}

/* ---------- renderers ---------- */

function renderCountdown() {
  const days = Math.ceil((VISARJAN_DATE - new Date()) / 86400000);
  const when = "Durga visarjan: 20 October 2026";
  $("#countdown").innerHTML = days > 0
    ? `<strong>${days}</strong><span>day${days === 1 ? "" : "s"} to go</span><span>${when}</span>`
    : `<span>${when}</span>`;
}

function renderSummary(d) {
  const cov = d.coverage;
  const b = cov.missing_breakdown;
  const cards = [
    ["Ghats in view", d.scope.sites.length, `${d.scope.events.length} festival test round(s)`],
    ["Readings reported", `${cov.reported_readings} / ${cov.expected_readings}`,
      `${Math.round((cov.coverage_ratio || 0) * 100)}% of expected readings`],
    ["Missing readings", cov.missing,
      `${b.not_sampled} not sampled · ${b.no_table_for_site} no table · ${b.row_absent} not printed`],
    ["Below detection (BDL)", d.counts.below_detection, "Very low, but not zero and not missing"],
  ];
  $("#summary-cards").innerHTML = cards.map(([t, v, s]) =>
    `<div class="card"><div class="card-label">${esc(t)}</div><div class="card-value">${esc(v)}</div>` +
    `<div class="card-sub">${esc(s)}</div></div>`).join("");
  $("#headlines").innerHTML = d.headlines.length
    ? d.headlines.map((h) => `<li>${esc(h)}</li>`).join("")
    : "<li>No readings with a CPCB limit in this selection.</li>";
}

function evidenceTable(rows) {
  return `<div class="table-wrap"><table><thead><tr><th>Round</th><th>Phase</th><th>Parameter</th>` +
    `<th>Value</th><th>Limit</th><th>Explanation</th><th>Source</th></tr></thead><tbody>` +
    rows.map((r) => `<tr><td>${esc(r.festival)} ${r.year}</td><td>${esc(PHASE[r.phase])}</td>` +
      `<td>${esc(r.parameter)}</td><td>${valueCell(r)}</td><td>${limitText(r.comparison)}</td>` +
      `<td>${esc(r.comparison && r.comparison.explanation)}</td><td>${sourceLink(r.source)}</td></tr>`).join("") +
    `</tbody></table></div>`;
}

function rankCard(r) {
  const pct = r.score == null ? 0 : Math.min(100, (r.score / 2) * 100);
  let warn = "";
  if (!r.assessable) {
    warn = `<p class="warn">Not ranked: no comparable readings in this selection. This is not evidence that the water meets the criteria.</p>`;
  } else if (r.low_coverage_warning) {
    warn = `<p class="warn">Limited data: ${r.readings_compared} of ${r.readings_expected} expected readings (${esc(r.coverage_level)} coverage). ` +
      `Missing readings are not treated as clean, so this result is less certain.</p>`;
  }
  const evidence = r.evidence.length
    ? `<details class="evidence"><summary>Evidence: ${r.evidence.length} readings furthest outside the limits</summary>${evidenceTable(r.evidence)}</details>`
    : "";
  const caveats = r.caveats.length
    ? `<ul class="card-caveats">${r.caveats.map((c) => `<li>${esc(c)}</li>`).join("")}</ul>` : "";
  return `<article class="ghat-card${r.assessable ? "" : " unranked"}">
    <header>
      <div class="rank" aria-label="Rank ${r.rank ?? "none"}">${r.rank ?? "—"}</div>
      <div class="ghat-name">
        <h3>${esc(r.site)}</h3>
        <p class="hi" lang="hi">${esc(r.name_hi)}</p>
        <p class="muted small">${esc(r.water_body)} · site match: ${esc(r.site_match_confidence)}</p>
      </div>
      <div class="score" title="Score 0–2: mean points per compared reading (see 'How the ranking works')">
        <div class="score-num">${r.score == null ? "—" : num(r.score)}<small> / 2</small></div>
        <div class="bar"><span style="width:${pct}%"></span></div>
        <div class="muted small">${r.readings_outside_criteria} of ${r.readings_compared} readings outside limits</div>
      </div>
    </header>
    <div class="chips">${r.parameters.map(paramChip).join("")}</div>
    ${warn}
    <ul class="reasons">${r.reasons.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
    ${evidence}${caveats}
    <button class="btn-secondary" data-site="${esc(r.site_id)}">All readings for this ghat</button>
  </article>`;
}

function renderMethod(m) {
  $("#method").innerHTML = `<summary>How the ranking works</summary>
    <p>${esc(m.score)}</p><p>${esc(m.phases)}</p><p>${esc(m.missing_data)}</p>
    <p>Ties are broken by: ${esc(m.tie_break.join(" → "))}.</p>
    <p>Not used in the score (no Class ${esc(m.cpcb_class)} limit): ${esc(m.not_scored.join(", "))}.</p>`;
}

function renderRankings(d, scopeLabel) {
  $("#rank-scope").textContent = scopeLabel ? `Selection: ${scopeLabel}.` : "";
  $("#rankings").innerHTML = d.rankings.length ? d.rankings.map(rankCard).join("") : "<p>No ghats in this selection.</p>";
  renderMethod(d.method);
}

function renderCoverage(d) {
  const events = d.scope.events;
  const head = events.map((e) => `<th>${esc(e.festival)} ${e.year}</th>`).join("");
  const rows = d.sites.map((s) => {
    const byKey = Object.fromEntries(s.events.map((e) => [`${e.year}-${e.festival}`, e]));
    const cells = events.map((e) => {
      const ev = byKey[`${e.year}-${e.festival}`];
      if (!ev) return `<td class="cov cov-na">—</td>`;
      const b = ev.missing_breakdown;
      const tip = `${ev.reported_readings} of ${ev.expected_readings} reported. Missing: ${b.not_sampled} not sampled, ` +
        `${b.no_table_for_site} no table, ${b.row_absent} not printed. BDL: ${ev.below_detection}.`;
      const label = ev.status === "no_table_in_report" ? "No table" : `${ev.reported_readings}/${ev.expected_readings}`;
      return `<td class="cov cov-${esc(ev.status)}" title="${esc(tip)}">${label}</td>`;
    }).join("");
    return `<tr><th scope="row"><button class="link" data-site="${esc(s.site_id)}">${esc(s.site)}</button></th>${cells}` +
      `<td>${s.reported_readings}/${s.expected_readings} (${Math.round((s.coverage_ratio || 0) * 100)}%)</td></tr>`;
  }).join("");
  $("#coverage").innerHTML = `<div class="table-wrap"><table><thead><tr><th>Ghat</th>${head}<th>Total</th></tr></thead>` +
    `<tbody>${rows}</tbody></table></div>`;
}

function renderBrief() {
  const b = state.brief;
  if (!b) return;
  const part = b[state.lang];
  $("#brief-title").textContent = part.title;
  const body = $("#brief-body");
  body.lang = state.lang;
  body.innerHTML = part.lines.map((l) => `<p>${esc(l)}</p>`).join("");
  $$(".tab").forEach((t) => t.setAttribute("aria-selected", String(t.dataset.lang === state.lang)));
}

function renderCaveats(list) {
  $("#caveats").innerHTML = [...new Set(list)].map((c) => `<li>${esc(c)}</li>`).join("");
}

/* ---------- ghat detail dialog ---------- */

async function openGhat(siteId) {
  const dlg = $("#ghat-dialog");
  const { params } = currentParams();
  $("#ghat-title").textContent = "Loading…";
  $("#ghat-body").innerHTML = "<p>Loading readings…</p>";
  if (!dlg.open) dlg.showModal();
  try {
    const res = await api(`/api/ghats/${encodeURIComponent(siteId)}/readings`, params);
    renderGhat(res.data);
  } catch (e) {
    $("#ghat-title").textContent = "Could not load ghat";
    $("#ghat-body").innerHTML = `<p class="banner">${esc(e.message)}</p>`;
  }
}

function renderGhat(d) {
  state.ghat = d;
  const g = d.ghat;
  const a = d.assessment;
  const params = [...new Set(d.readings.map((r) => r.parameter))];
  $("#ghat-title").textContent = g.site;
  $("#ghat-body").innerHTML = `
    <p class="hi" lang="hi">${esc(g.name_hi)}</p>
    <p class="muted small">${esc(g.water_body)} · site match: ${esc(g.site_match_confidence)} ·
      printed in reports as: ${g.names_as_printed.map(esc).join(" | ")}</p>
    ${g.caveats.length ? `<ul class="card-caveats">${g.caveats.map((c) => `<li>${esc(c)}</li>`).join("")}</ul>` : ""}
    ${a ? `<h3>Against CPCB Class B (this selection)</h3>
      <div class="chips">${a.parameters.map(paramChip).join("")}</div>
      <ul class="reasons">${a.reasons.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}
    <h3>Coverage by test round</h3>
    <div class="chips">${d.coverage.events.map((e) =>
      `<span class="chip cov-${esc(e.status)}">${esc(e.festival)} ${e.year}: ${e.status === "no_table_in_report"
        ? "no table in report" : `${e.reported_readings}/${e.expected_readings} reported`}</span>`).join("")}</div>
    <h3>Readings</h3>
    <div class="dialog-filters">
      <label>Parameter
        <select id="g-param"><option value="">All parameters</option>
          ${params.map((p) => `<option value="${esc(p)}">${esc(p)}</option>`).join("")}</select>
      </label>
      <label class="chk"><input type="checkbox" id="g-flagged"> Only readings outside limits or missing</label>
    </div>
    <div id="g-table"></div>
    <p class="muted small">* Units are assumed because the reports print none. BDL = below detection limit (very low, not zero).</p>`;
  $("#g-param").addEventListener("change", renderGhatTable);
  $("#g-flagged").addEventListener("change", renderGhatTable);
  renderGhatTable();
}

function renderGhatTable() {
  const d = state.ghat;
  if (!d) return;
  const p = $("#g-param").value;
  const flagged = $("#g-flagged").checked;
  const rows = d.readings.filter((r) => (!p || r.parameter === p) &&
    (!flagged || r.measurement_status === "missing" || (r.comparison && r.comparison.status === "does_not_meet")));
  $("#g-table").innerHTML = rows.length
    ? `<div class="table-wrap"><table><thead><tr><th>Round</th><th>Phase</th><th>Parameter</th><th>Value</th>` +
      `<th>Status</th><th>Explanation</th><th>Source</th></tr></thead><tbody>` +
      rows.map((r) => `<tr><td>${esc(r.festival)} ${r.year}</td><td>${esc(PHASE[r.phase])}</td>` +
        `<td>${esc(r.parameter)}${r.parameter_as_printed && r.parameter_as_printed !== r.parameter
          ? ` <span class="unit">(${esc(r.parameter_as_printed)})</span>` : ""}</td>` +
        `<td>${valueCell(r)}</td><td>${statusChip(r)}</td>` +
        `<td>${esc(r.comparison && r.comparison.explanation)}</td><td>${sourceLink(r.source)}</td></tr>`).join("") +
      `</tbody></table></div>`
    : "<p>No readings match these filters.</p>";
}

/* ---------- actions ---------- */

async function copyText(text, buttonSel) {
  if (!text) return;
  const btn = $(buttonSel);
  const original = btn.textContent;
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
  btn.textContent = "Copied ✓";
  setTimeout(() => { btn.textContent = original; }, 1500);
}

function downloadBrief() {
  const b = state.brief;
  if (!b) return;
  const text = `${b.en.text}\n\n${b.hi.text}\n`;
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = `jal-drishti-brief-${new Date().toISOString().slice(0, 10)}.txt`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/* ---------- loading ---------- */

async function load() {
  const { params, noYears } = currentParams();
  if (noYears) { showError("Select at least one year."); return; }
  clearError();
  const seq = ++state.loadSeq;
  setLoading(true);
  try {
    const [summary, rankings, coverage, brief] = await Promise.all([
      api("/api/summary", params),
      api("/api/rankings", params),
      api("/api/coverage", params),
      api("/api/brief", { ...params, top: state.top }),
    ]);
    if (seq !== state.loadSeq) return; // a newer filter change is in flight
    state.brief = brief.data;
    renderSummary(summary.data);
    renderRankings(rankings.data, brief.data.scope.label_en);
    renderCoverage(coverage.data);
    renderBrief();
    renderCaveats(rankings.meta.caveats);
  } catch (e) {
    if (seq === state.loadSeq) showError(e.message);
  } finally {
    if (seq === state.loadSeq) setLoading(false);
  }
}

async function loadBrief() {
  const { params, noYears } = currentParams();
  if (noYears) return;
  try {
    const b = await api("/api/brief", { ...params, top: state.top });
    state.brief = b.data;
    renderBrief();
  } catch (e) {
    showError(e.message);
  }
}

function bindEvents() {
  $("#f-festival").addEventListener("change", load);
  $("#f-phase").addEventListener("change", load);
  $("#brief-top").addEventListener("change", (e) => { state.top = Number(e.target.value); loadBrief(); });
  $$(".tab").forEach((t) => t.addEventListener("click", () => { state.lang = t.dataset.lang; renderBrief(); }));
  $("#copy-brief").addEventListener("click", () => copyText(state.brief && state.brief[state.lang].text, "#copy-brief"));
  $("#copy-both").addEventListener("click", () =>
    state.brief && copyText(`${state.brief.en.text}\n\n${state.brief.hi.text}`, "#copy-both"));
  $("#download-brief").addEventListener("click", downloadBrief);
  const dlg = $("#ghat-dialog");
  $("#ghat-close").addEventListener("click", () => dlg.close());
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });
  document.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-site]");
    if (btn) openGhat(btn.dataset.site);
  });
}

async function init() {
  renderCountdown();
  bindEvents();
  try {
    const health = await api("/api/health");
    state.allYears = [...new Set(health.data.events.map((e) => e.year))].sort();
    $("#f-years").innerHTML = state.allYears.map((y) =>
      `<label class="chk"><input type="checkbox" value="${y}" checked> ${y}</label>`).join("");
    $("#f-years").addEventListener("change", load);
  } catch (e) {
    showError(e.message);
    return;
  }
  load();
}

document.addEventListener("DOMContentLoaded", init);
'''

# ---------------------------------------------------------------- backend patches

CONFIG_ADDITION = '''

FRONTEND_DIR_ENV = "JAL_DRISHTI_FRONTEND_DIR"


def resolve_frontend_dir() -> Path:
    env = os.environ.get(FRONTEND_DIR_ENV)
    return Path(env) if env else REPO_ROOT / "frontend"
'''

API_IMPORT_ANCHOR = "from .config import CORS_ENV, CRITERIA_SOURCE, DEFAULT_CPCB_CLASS\n"
API_IMPORTS = ("from fastapi.staticfiles import StaticFiles\n"
               "from .config import resolve_frontend_dir\n")
API_RETURN_ANCHOR = "\n    return app\n"
API_MOUNT = '''
    frontend = resolve_frontend_dir()
    if (frontend / "index.html").is_file():
        # Mounted last so every /api route takes priority.
        app.mount("/", StaticFiles(directory=str(frontend), html=True), name="frontend")

    return app
'''


def backup(path: Path) -> None:
    bak = path.with_name(path.name + ".bak")
    if not bak.exists():
        shutil.copy2(path, bak)


def patch_config(path: Path) -> str:
    if not path.is_file():
        return f"SKIPPED: {path} not found"
    text = path.read_text(encoding="utf-8")
    if "FRONTEND_DIR_ENV" in text:
        return f"already patched: {path}"
    backup(path)
    path.write_text(text.rstrip("\n") + "\n" + CONFIG_ADDITION, encoding="utf-8")
    return f"patched: {path}"


def patch_api(path: Path) -> str:
    if not path.is_file():
        return f"SKIPPED: {path} not found"
    text = path.read_text(encoding="utf-8")
    if "resolve_frontend_dir" in text:
        return f"already patched: {path}"
    if API_IMPORT_ANCHOR not in text or API_RETURN_ANCHOR not in text:
        return (f"COULD NOT PATCH {path}: expected lines not found. Add the StaticFiles import and the "
                f"app.mount(...) block by hand (see the frontend instructions).")
    backup(path)
    text = text.replace(API_IMPORT_ANCHOR, API_IMPORT_ANCHOR + API_IMPORTS, 1)
    idx = text.rfind(API_RETURN_ANCHOR)  # the 'return app' at the end of create_app()
    text = text[:idx] + "\n" + API_MOUNT + text[idx + len(API_RETURN_ANCHOR):]
    path.write_text(text, encoding="utf-8")
    return f"patched: {path}"


def main() -> None:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    root = root.resolve()
    if not (root / "backend" / "jal_drishti").is_dir():
        print(f"Warning: {root / 'backend' / 'jal_drishti'} not found. Frontend files will still be written,")
        print("but the backend will not be patched. Run this from the repo root (the folder with backend/ and data/).")

    for rel, content in FILES.items():
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content.lstrip("\n"), encoding="utf-8")
        print(f"wrote: {path}")

    print(patch_config(root / "backend" / "jal_drishti" / "config.py"))
    print(patch_api(root / "backend" / "jal_drishti" / "api.py"))

    print("\nDone. Next:")
    print("  cd backend")
    print("  uvicorn jal_drishti.api:app --port 8000")
    print("  open http://localhost:8000/")


if __name__ == "__main__":
    main()